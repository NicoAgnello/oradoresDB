-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.1.0 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando estructura para tabla integrador_cac.oradores
CREATE TABLE IF NOT EXISTS `oradores` (
  `id_orador` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `apellido` varchar(40) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `mail` varchar(100) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `tema` varchar(100) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id_orador`),
  UNIQUE KEY `mail` (`mail`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla integrador_cac.oradores: ~10 rows (aproximadamente)
INSERT INTO `oradores` (`id_orador`, `nombre`, `apellido`, `mail`, `tema`, `fecha_alta`) VALUES
	(1, 'Nicolas', 'Perez', 'nicolasperez@hotmail.com', 'abc123', '2023-11-11 21:35:13'),
	(2, 'Jorge', 'Pomba', 'jorgitopomba@hotmail.com', 'abc111', '2023-11-11 21:35:40'),
	(3, 'Cirilla', 'Chuik', 'cirichuik@gmail.com', 'abb122', '2023-11-11 21:36:26'),
	(4, 'Jorgelina', 'Rumin', 'jorrumin@gmail.com', 'aaa111', '2023-11-11 21:37:00'),
	(5, 'Jose', 'Patar', 'josepatar@hotmail.com', 'ccc333', '2023-11-11 21:37:24'),
	(6, 'Maria', 'Burssi', 'mariaburssi@gmail.com', 'bac123', '2023-11-11 21:38:09'),
	(7, 'Alicia', 'Gomez', 'aliciagomez@hotmail.com', 'ast133', '2023-11-11 21:38:44'),
	(8, 'Ruben', 'Cerilli', 'rubenc@gmail.com', 'abb222', '2023-11-11 21:39:03'),
	(9, 'Nicolas', 'Torcelli', 'nicotorcelli@gmail.com', 'fff233', '2023-11-11 21:39:40'),
	(10, 'Gustavo', 'Piva', 'gustavopiva@hotmail.com', 'eee111', '2023-11-11 21:40:15');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
